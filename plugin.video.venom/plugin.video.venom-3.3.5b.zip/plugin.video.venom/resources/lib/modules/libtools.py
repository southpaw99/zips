# -*- coding: utf-8 -*-

try:
	from sqlite3 import dbapi2 as database
except:
	from pysqlite2 import dbapi2 as database

import datetime
import json
import os
import re
import sys
import urllib
import urlparse
import xbmc, xbmcvfs

from resources.lib.modules import control
from resources.lib.modules import cleantitle
from resources.lib.modules import log_utils

notificationSound = False if control.setting('notification.sound') == 'false' else True


class lib_tools:
	@staticmethod
	def create_folder(folder):
		try:
			folder = xbmc.makeLegalFilename(folder)
			control.makeFile(folder)

			try:
				if 'ftp://' not in folder:
					raise Exception()

				from ftplib import FTP
				ftparg = re.compile('ftp://(.+?):(.+?)@(.+?):?(\d+)?/(.+/?)').findall(folder)
				ftp = FTP(ftparg[0][2], ftparg[0][0], ftparg[0][1])

				try:
					ftp.cwd(ftparg[0][4])
				except:
					ftp.mkd(ftparg[0][4])
				ftp.quit()
			except:
				pass
		except:
			pass


	@staticmethod
	def write_file(path, content):
		try:
			path = xbmc.makeLegalFilename(path)

			if not isinstance(content, basestring):
				content = str(content)

			file = control.openFile(path, 'w')
			file.write(str(content))
			file.close()
		except Exception as e:
			pass


	@staticmethod
	def nfo_url(media_string, ids):
		tvdb_url = 'https://thetvdb.com/?tab=series&id=%s'
		tmdb_url = 'https://www.themoviedb.org/%s/%s'
		imdb_url = 'https://www.imdb.com/title/%s/'

		if 'tvdb' in ids:
			return tvdb_url % (str(ids['tvdb']))

		elif 'tmdb' in ids:
			return tmdb_url % (media_string, str(ids['tmdb']))

		elif 'imdb' in ids:
			return imdb_url % (str(ids['imdb']))

		else:
			return ''


	@staticmethod
	def check_sources(title, year, imdb, tvdb = None, season = None, episode = None, tvshowtitle = None, premiered = None):
		try:
			from resources.lib.modules import sources
			src = sources.Sources().getSources(title, year, imdb, tvdb, season, episode, tvshowtitle, premiered)
			return src and len(src) > 5
		except:
			return False


	@staticmethod
	def legal_filename(filename):
		try:
			filename = filename.strip()
			filename = re.sub(r'(?!%s)[^\w\-_\.]', '.', filename)
			filename = re.sub('\.+', '.', filename)
			filename = re.sub(re.compile('(CON|PRN|AUX|NUL|COM\d|LPT\d)\.', re.I), '\\1_', filename)
			xbmc.makeLegalFilename(filename)
			return filename
		except:
			return filename


	@staticmethod
	def make_path(base_path, title, year = '', season = ''):
		show_folder = re.sub(r'[^\w\-_\. ]', '_', title)
		show_folder = '%s (%s)' % (show_folder, year) if year else show_folder
		path = os.path.join(base_path, show_folder)

		if season:
			path = os.path.join(path, 'Season %s' % season)

		return path


	@staticmethod
	def ckKodiSources(paths=None):
		# Check if the path was added to the Kodi sources.
		# If not, ask user to run full auto setup.
		contains = False
		try:
			if paths == None:
				paths = []
				movie_LibraryFolder = os.path.join(control.transPath(control.setting('library.movie')), '')
				paths.append(movie_LibraryFolder)

				tvShows_LibraryFolder = os.path.join(control.transPath(control.setting('library.tv')),'')
				paths.append(tvShows_LibraryFolder)

			paths = [i.rstrip('/').rstrip('\\') for i in paths]

			result = control.jsonrpc('{"jsonrpc": "2.0", "method": "Files.GetSources", "params": {"media" : "video"}, "id": 1}')
			result = unicode(result, 'utf-8', errors='ignore')
			result = json.loads(result)['result']['sources']

			for i in result:
				if i['file'].rstrip('/').rstrip('\\') in paths:
					contains = True
					break
		except:
			log_utils.error()

		if not contains:
			msg = 'Your Library Folders do not exist in Kodi Sources.  Would you like to run full setup of Library Folders to Kodi Sources now?'
			if control.yesnoDialog(msg, '', ''):
				lib_tools().total_setup()

		return contains


	@staticmethod
	def clean():
		control.execute('CleanLibrary(video)')


	@staticmethod
	def total_setup():
		try:
			# control.execute('CleanLibrary(video)')
			libmovies().auto_movie_setup()
			libtvshows().auto_tv_setup()
			control.notification(title = 'default', message = 'Restart Kodi for changes is required', icon = 'default', time = 50, sound = notificationSound)
		except:
			log_utils.error()
			control.notification(title = 'default', message = 'Folders Failed to add to Kodi Sources', icon = 'default', time = 50, sound = notificationSound)


class libmovies:
	def __init__(self):
		self.library_folder = os.path.join(control.transPath(control.setting('library.movie')), '')
		# self.library_folder = control.setting('library.movie')

		self.check_setting = control.setting('library.check_movie') or 'false'
		self.library_setting = control.setting('library.update') or 'true'
		self.dupe_setting = control.setting('library.check') or 'true'
		self.silentDialog = False
		self.infoDialog = False


	def setup_library(self):
		# if self.library_folder[-1] != '/':
			# self.library_folder += '/'
			# log_utils.log('self.library_folder = %s' % str(self.library_folder), __name__, log_utils.LOGDEBUG)
		try:
			if not xbmcvfs.exists(self.library_folder):
				xbmcvfs.mkdir(self.library_folder)
			msg = 'Would you like to automatically set Venom as a Movies video source?'
			if control.yesnoDialog('Library setup', msg, ''):
				# icon = os.path.join(control.artPath(), 'libmovies.png')
				icon = 'DefaultMovies.png'
				source_name = 'Venom Movies'
				source_content = "('%s','movies','metadata.themoviedb.org','',2147483647,1,'<settings version=\"2\"><setting id=\"certprefix\" default=\"true\">Rated </setting><setting id=\"fanart\">true</setting><setting id=\"imdbanyway\">true</setting><setting id=\"keeporiginaltitle\" default=\"true\">false</setting><setting id=\"language\" default=\"true\">en</setting><setting id=\"RatingS\" default=\"true\">TMDb</setting><setting id=\"tmdbcertcountry\" default=\"true\">us</setting><setting id=\"trailer\">true</setting></settings>',0,0,NULL,NULL)" % self.library_folder
				control.add_source(source_name, self.library_folder, source_content, icon)

			return xbmc.translatePath(self.library_folder)

		except:
			log_utils.error()


	def auto_movie_setup(self):
		# if self.library_folder[-1] != '/':
			# self.library_folder += '/'
		try:
			xbmcvfs.mkdir(self.library_folder)
			# icon = os.path.join(control.artPath(), 'libmovies.png')
			icon = 'DefaultMovies.png'
			source_name = 'Venom Movies'
			source_content = "('%s','movies','metadata.themoviedb.org','',2147483647,1,'<settings version=\"2\"><setting id=\"certprefix\" default=\"true\">Rated </setting><setting id=\"fanart\">true</setting><setting id=\"imdbanyway\">true</setting><setting id=\"keeporiginaltitle\" default=\"true\">false</setting><setting id=\"language\" default=\"true\">en</setting><setting id=\"RatingS\" default=\"true\">TMDb</setting><setting id=\"tmdbcertcountry\" default=\"true\">us</setting><setting id=\"trailer\">true</setting></settings>',0,0,NULL,NULL)" % self.library_folder
			control.add_source(source_name, self.library_folder, source_content, icon)

			return True
		except:
			log_utils.error()
			False


	def add(self, name, title, year, imdb, tmdb, range=False):
		if not control.condVisibility('Window.IsVisible(infodialog)') and not control.condVisibility('Player.HasVideo')\
				and self.silentDialog is False:
			control.notification(title = name, message = 32552, icon = 'default', time = 1, sound = notificationSound)
			self.infoDialog = True

		try:
			if not self.dupe_setting == 'true':
				raise Exception()

			id = [imdb, tmdb] if tmdb != '0' else [imdb]
			# lib = control.jsonrpc('{"jsonrpc": "2.0", "method": "VideoLibrary.GetMovies", "params": {"filter":{"or": [{"field": "year", "operator": "is", "value": "%s"}, {"field": "year", "operator": "is", "value": "%s"}, {"field": "year", "operator": "is", "value": "%s"}]}, "properties" : ["imdbnumber", "originaltitle", "year"]}, "id": 1}' % (year, str(int(year)+1), str(int(year)-1)))
			lib = control.jsonrpc('{"jsonrpc": "2.0", "method": "VideoLibrary.GetMovies", "params": {"filter":{"or": [{"field": "year", "operator": "is", "value": "%s"}, {"field": "year", "operator": "is", "value": "%s"}, {"field": "year", "operator": "is", "value": "%s"}]}, "properties" : ["imdbnumber", "title", "originaltitle", "year"]}, "id": 1}' % (year, str(int(year)+1), str(int(year)-1)))
			lib = unicode(lib, 'utf-8', errors = 'ignore')

			lib = json.loads(lib)['result']['movies']
			# lib = [i for i in lib if str(i['imdbnumber']) in id or (i['originaltitle'].encode('utf-8') == title and str(i['year']) == year)][0]
			lib = [i for i in lib if str(i['imdbnumber']) in id or (cleantitle.get(title) in [cleantitle.get(i['title'].encode('utf-8')), cleantitle.get(i['originaltitle'].encode('utf-8'))] and str(i['year']) == year)]

		except:
			lib = []

		files_added = 0

		try:
			if lib != []:
				raise Exception()

			if self.check_setting == 'true':
				src = lib_tools.check_sources(title, year, imdb, None, None, None, None, None)
				if not src:
					raise Exception()

			self.strmFile({'name': name, 'title': title, 'year': year, 'imdb': imdb, 'tmdb': tmdb})
			files_added += 1
		except:
			pass

		if files_added == 0:
			control.notification(title = name, message = 32652, icon = 'default', time = 5, sound = notificationSound)

		if range is True:
			return files_added

		contains = lib_tools.ckKodiSources()

		if self.library_setting == 'true' and not control.condVisibility('Library.IsScanningVideo') and files_added > 0:
			if contains:
				control.notification(title = name, message = 32554, icon = 'default', time = 5, sound = notificationSound)
				control.sleep(4000)
				control.execute('UpdateLibrary(video)')
			else:
				control.notification(title = name, message = 'strm file written but library cannot be updated', icon = 'default', time = 20, sound = notificationSound)


	def silent(self, url):
		control.idle()

		if not control.condVisibility('Window.IsVisible(infodialog)') and not control.condVisibility('Player.HasVideo'):
			control.notification(title = 'default', message = 32552, icon = 'default', time = 10000000, sound = notificationSound)
			self.infoDialog = True
			self.silentDialog = True

		from resources.lib.menus import movies
		items = movies.Movies().get(url, idx=False)
		if items is None:
			items = []

		for i in items:
			try:
				if xbmc.abortRequested is True:
					return sys.exit()
				self.add('%s (%s)' % (i['title'], i['year']), i['title'], i['year'], i['imdb'], i['tmdb'], range=True)
			except:
				pass

		if self.infoDialog is True:
			self.silentDialog = False
			control.notification(title = 'default', message = 'Trakt Movies Sync Complete', icon = 'default', time = 1, sound = notificationSound)


	def range(self, url, list_name):
		control.idle()

		if not control.yesnoDialog(control.lang(32555).encode('utf-8'), '', ''):
			return

		if 'traktcollection' in url:
			message = 32661
		if 'traktwatchlist' in url:
			message = 32662
		if '/lists/' in url:
			message = 32672
		if '/likes/' in url:
			message = 32673

		if not control.condVisibility('Window.IsVisible(infodialog)') and not control.condVisibility('Player.HasVideo'):
			control.notification(title = 'default', message = message, icon = 'default', time = 1, sound = notificationSound)
			self.infoDialog = True

		from resources.lib.menus import movies
		items = movies.Movies().get(url, idx=False)
		if items is None or items == []:
			control.notification(title = message, message = 33049, icon = 'INFO', sound=notificationSound)
			return

		contains = lib_tools.ckKodiSources()

		for i in items:
			try:
				if xbmc.abortRequested is True:
					return sys.exit()
				files_added = self.add('%s (%s)' % (i['title'], i['year']), i['title'], i['year'], i['imdb'], i['tmdb'], range=True)
				if self.library_setting == 'true' and not control.condVisibility('Library.IsScanningVideo') and files_added > 0:
					if contains:
						control.notification(title = '%s (%s)' % (i['title'], i['year']), message = 32554, icon = 'default', time = 1, sound = notificationSound)
					else:
						control.notification(title = '%s (%s)' % (i['title'], i['year']), message = 'strm file written but library cannot be updated', icon = 'default', time = 20, sound = notificationSound)
			except:
				log_utils.error()
				pass

		if self.library_setting == 'true' and not control.condVisibility('Library.IsScanningVideo'):
			if contains:
				control.sleep(5000)
				control.execute('UpdateLibrary(video)')

				if '/users/' in url:
					try:
						control.makeFile(control.dataPath)
						dbcon = database.connect(control.libcacheFile)
						dbcur = dbcon.cursor()
						dbcur.execute("CREATE TABLE IF NOT EXISTS lists (""list_name TEXT, ""url TEXT, ""UNIQUE(list_name, url)"");")
						dbcur.execute("INSERT OR REPLACE INTO lists Values (?, ?)", (list_name, url))
						dbcur.connection.commit()
					except:
						log_utils.error()
						return
					dbcon.close()

			else:
				control.notification(title = 'default', message = 'strm files written but library cannot be updated', icon = 'default', time = 20, sound = notificationSound)


	def strmFile(self, i):
		try:
			name, title, year, imdb, tmdb = i['name'], i['title'], i['year'], i['imdb'], i['tmdb']

			sysname, systitle = urllib.quote_plus(name), urllib.quote_plus(title)

			transtitle = cleantitle.normalize(title.translate(None, '\/:*?"<>|'))

			content = '%s?action=play&name=%s&title=%s&year=%s&imdb=%s&tmdb=%s' % (sys.argv[0], sysname, systitle, year, imdb, tmdb)

			folder = lib_tools.make_path(self.library_folder, transtitle, year)

			lib_tools.create_folder(folder)
			lib_tools.write_file(os.path.join(folder, lib_tools.legal_filename(transtitle) + '.' + year + '.strm'), content)
			lib_tools.write_file(os.path.join(folder, lib_tools.legal_filename(transtitle) + '.' + year + '.nfo'), lib_tools.nfo_url('movie', i))
		except:
			pass


class libtvshows:
	def __init__(self):
		self.library_folder = os.path.join(control.transPath(control.setting('library.tv')),'')

		self.version = control.version()

		self.check_setting = control.setting('library.check_episode') or 'false'
		self.include_unknown = control.setting('library.include_unknown') or 'true'
		self.library_setting = control.setting('library.update') or 'true'
		self.dupe_setting = control.setting('library.check') or 'true'

		self.datetime = (datetime.datetime.utcnow() - datetime.timedelta(hours = 5))
		if control.setting('library.importdelay') != 'true':
			self.date = self.datetime.strftime('%Y%m%d')
		else:
			self.date = (self.datetime - datetime.timedelta(hours = 24)).strftime('%Y%m%d')

		self.silentDialog = False
		self.infoDialog = False
		self.block = False

		self.showunaired = control.setting('showunaired') or 'true'


	def setup_library(self):
		# if self.library_folder[-1] != '/':
			# self.library_folder += '/'
			# log_utils.log('self.library_folder = %s' % str(self.library_folder), __name__, log_utils.LOGDEBUG)
		try:
			if not xbmcvfs.exists(self.library_folder):
				xbmcvfs.mkdir(self.library_folder)
			msg = 'Would you like to automatically set Venom as a TVShows video source?'
			if control.yesnoDialog('Library setup', msg, ''):
				# icon = os.path.join(control.artPath(), 'libtv.png')
				icon = 'DefaultTVShows.png'
				source_name = 'Venom TV Shows'
				source_content = "('%s','tvshows','metadata.tvdb.com','',0,0,'<settings version=\"2\"><setting id=\"absolutenumber\" default=\"true\">false</setting><setting id=\"alsoimdb\">true</setting><setting id=\"dvdorder\" default=\"true\">false</setting><setting id=\"fallback\">true</setting><setting id=\"fallbacklanguage\">es</setting><setting id=\"fanart\">true</setting><setting id=\"language\" default=\"true\">en</setting><setting id=\"RatingS\" default=\"true\">TheTVDB</setting><setting id=\"usefallbacklanguage1\">true</setting></settings>',0,0,NULL,NULL)" % self.library_folder
				control.add_source(source_name, self.library_folder, source_content, icon)

			return xbmc.translatePath(self.library_folder)

		except:
			log_utils.error()


	def auto_tv_setup(self):
		# if self.library_folder[-1] != '/':
			# self.library_folder += '/'
		try:
			xbmcvfs.mkdir(self.library_folder)
			icon = os.path.join(control.artPath(), 'libtv.png')
			icon = 'DefaultTVShows.png'
			source_name = 'Venom TV Shows'
			source_content = "('%s','tvshows','metadata.tvdb.com','',0,0,'<settings version=\"2\"><setting id=\"absolutenumber\" default=\"true\">false</setting><setting id=\"alsoimdb\">true</setting><setting id=\"dvdorder\" default=\"true\">false</setting><setting id=\"fallback\">true</setting><setting id=\"fallbacklanguage\">es</setting><setting id=\"fanart\">true</setting><setting id=\"language\" default=\"true\">en</setting><setting id=\"RatingS\" default=\"true\">TheTVDB</setting><setting id=\"usefallbacklanguage1\">true</setting></settings>',0,0,NULL,NULL)" % self.library_folder
			control.add_source(source_name, self.library_folder, source_content, icon)

			return True
		except:
			log_utils.error()
			False


	def add(self, tvshowtitle, year, imdb, tvdb, range=False):
		if not control.condVisibility('Window.IsVisible(infodialog)') and not control.condVisibility('Player.HasVideo')\
				and self.silentDialog is False:
			control.notification(title = tvshowtitle, message = 32552, icon = 'default', time = 10000000, sound =notificationSound )
			self.infoDialog = True

		try:
			from resources.lib.menus import episodes
			items = episodes.Episodes().get(tvshowtitle, year, imdb, tvdb, idx=False)
		except:
			log_utils.error()
			pass

		status = items[0]['status'].lower()

		try:
			items = [{'title': i['title'], 'year': i['year'], 'imdb': i['imdb'], 'tvdb': i['tvdb'], 'season': i['season'], 'episode': i['episode'], 'tvshowtitle': i['tvshowtitle'], 'premiered': i['premiered']} for i in items]
		except:
			items = []

		try:
			if self.dupe_setting != 'true':
				raise Exception()

			if items == []:
				raise Exception()

			id = [items[0]['imdb'], items[0]['tvdb']]

			lib = control.jsonrpc('{"jsonrpc": "2.0", "method": "VideoLibrary.GetTVShows", "params": {"properties" : ["imdbnumber", "title", "year"]}, "id": 1}')
			# lib = control.jsonrpc('{"jsonrpc": "2.0", "method": "VideoLibrary.GetTVShows", "params": {"filter":{"or": [{"field": "year", "operator": "is", "value": "%s"}, {"field": "year", "operator": "is", "value": "%s"}, {"field": "year", "operator": "is", "value": "%s"}]}, "properties": ["imdbnumber", "title"]}, "id": 1}' % years)
			lib = unicode(lib, 'utf-8', errors='ignore')
			lib = json.loads(lib)['result']['tvshows']

			lib = [i['title'].encode('utf-8') for i in lib if str(i['imdbnumber']) in id or (i['title'].encode('utf-8') == items[0]['tvshowtitle'] and str(i['year']) == items[0]['year'])][0]

			lib = control.jsonrpc('{"jsonrpc": "2.0", "method": "VideoLibrary.GetEpisodes", "params": {"filter":{"and": [{"field": "tvshow", "operator": "is", "value": "%s"}]}, "properties": ["season", "episode"]}, "id": 1}' % lib)
			# lib = control.jsonrpc('{"jsonrpc": "2.0", "method": "VideoLibrary.GetEpisodes", "params": {"filter":{"and": [{"field": "season", "operator": "is", "value": "%s"}, {"field": "episode", "operator": "is", "value": "%s"}]}, "properties": ["file"], "tvshowid": %s }, "id": 1}' % (str(season), str(episode), str(results['tvshowid'])))
			lib = unicode(lib, 'utf-8', errors='ignore')
			lib = json.loads(lib)['result']['episodes']

			lib = ['S%02dE%02d' % (int(i['season']), int(i['episode'])) for i in lib]

			items = [i for i in items if not 'S%02dE%02d' % (int(i['season']), int(i['episode'])) in lib]
		except:
			pass

		files_added = 0

		for i in items:
			try:
				if xbmc.abortRequested is True:
					return sys.exit()

				if self.check_setting == 'true':
					if i['episode'] == '1':
						self.block = True
						src = lib_tools.check_sources(i['title'], i['year'], i['imdb'], i['tvdb'], i['season'], i['episode'], i['tvshowtitle'], i['premiered'])
						if src:
							self.block = False
					if self.block is True:
						continue

				premiered = i.get('premiered', '0')

				# Show Season Special(Season0).
				if int(i['season']) == 0 and control.setting('tv.specials') == 'false':
					continue

				# Show Unaired items.
				if status.lower() == 'ended':
					pass
				elif premiered == '0':
					continue
				elif int(re.sub('[^0-9]', '', str(premiered))) > int(re.sub('[^0-9]', '', str(self.date))):
					unaired = 'true'
					if self.showunaired != 'true':
						continue

				self.strmFile(i)
				files_added += 1
			except:
				log_utils.error()
				pass

		if files_added == 0:
			control.notification(title = tvshowtitle, message = 32652, icon = 'default', time = 5, sound = notificationSound)

		if range is True:
			return files_added

		contains = lib_tools.ckKodiSources()

		if self.library_setting == 'true' and not control.condVisibility('Library.IsScanningVideo') and files_added > 0:
			if contains:
				control.notification(title = tvshowtitle, message = 32554, icon = 'default', time = 5, sound = notificationSound)
				control.execute('UpdateLibrary(video)')
			else:
				control.notification(title = name, message = 'strm file written but library cannot be updated', icon = 'default', time = 20, sound = notificationSound)


	def silent(self, url):
		control.idle()

		if not control.condVisibility('Window.IsVisible(infodialog)') and not control.condVisibility('Player.HasVideo'):
			control.notification(title = 'default', message = 32608, icon = 'default', time = 10000000, sound = notificationSound)
			self.infoDialog = True
			self.silentDialog = True

		from resources.lib.menus import tvshows
		items = tvshows.TVshows().get(url, idx=False)
		if items is None:
			items = []

		for i in items:
			try:
				if xbmc.abortRequested is True:
					return sys.exit()
				self.add(i['title'], i['year'], i['imdb'], i['tvdb'], range=True)
			except:
				pass

		if self.infoDialog is True:
			self.silentDialog = False
			control.notification(title = 'default', message = 'Trakt TV Show Sync Complete', icon = 'default', time = 1, sound = notificationSound)


	def range(self, url, list_name):
		control.idle()

		if not control.yesnoDialog(control.lang(32555).encode('utf-8'), '', ''):
			return

		if 'traktcollection' in url:
			message = 32661
		if 'traktwatchlist' in url:
			message = 32662
		if '/lists/' in url:
			message = 32674
		if '/likes/' in url:
			message = 32675

		if not control.condVisibility('Window.IsVisible(infodialog)') and not control.condVisibility('Player.HasVideo'):
			control.notification(title = 'default', message = message, icon = 'default', time = 10000000, sound = notificationSound)
			self.infoDialog = True

		from resources.lib.menus import tvshows
		items = tvshows.TVshows().get(url, idx=False)

		if items is None or items == []:
			control.notification(title = message, message = 33049, icon = 'INFO', sound=notificationSound)
			return

		contains = lib_tools.ckKodiSources()

		for i in items:
			try:
				if xbmc.abortRequested is True:
					return sys.exit()
				files_added = self.add(i['title'], i['year'], i['imdb'], i['tvdb'], range=True)
				if self.library_setting == 'true' and not control.condVisibility('Library.IsScanningVideo') and files_added > 0:
					if contains:
						control.notification(title = i['title'], message = 32554, icon = 'default', time = 1, sound = notificationSound)
					else:
						control.notification(title = i['title'], message = 'strm file written but library cannot be updated', icon = 'default', time = 20, sound = notificationSound)
			except:
				log_utils.error()
				pass

		if self.library_setting == 'true' and not control.condVisibility('Library.IsScanningVideo'):
			if contains:
				control.sleep(5000)
				control.execute('UpdateLibrary(video)')

				if '/users/' in url:
					try:
						control.makeFile(control.dataPath)
						dbcon = database.connect(control.libcacheFile)
						dbcur = dbcon.cursor()
						dbcur.execute("CREATE TABLE IF NOT EXISTS lists (""list_name TEXT, ""url TEXT, ""UNIQUE(list_name, url)"");")
						dbcur.execute("INSERT OR REPLACE INTO lists Values (?, ?)", (list_name, url))
						dbcur.connection.commit()
					except:
						log_utils.error()
						return
					dbcon.close()

			else:
				control.notification(title = 'default', message = 'strm files written but library cannot be updated', icon = 'default', time = 20, sound = notificationSound)


	def strmFile(self, i):
		try:
			title, year, imdb, tvdb, season, episode, tvshowtitle, premiered = i['title'], i['year'], i['imdb'], i['tvdb'], i['season'], i['episode'], i['tvshowtitle'], i['premiered']

			episodetitle = urllib.quote_plus(title)
			systitle, syspremiered = urllib.quote_plus(tvshowtitle), urllib.quote_plus(premiered)

			transtitle = cleantitle.normalize(tvshowtitle.translate(None, '\/:*?"<>|'))

			content = '%s?action=play&title=%s&year=%s&imdb=%s&tvdb=%s&season=%s&episode=%s&tvshowtitle=%s&premiered=%s' % (
							sys.argv[0], episodetitle, year, imdb, tvdb, season, episode, systitle, syspremiered)

			folder = lib_tools.make_path(self.library_folder, transtitle, year)
			if not os.path.isfile(os.path.join(folder, 'tvshow.nfo')):
				lib_tools.create_folder(folder)
				lib_tools.write_file(os.path.join(folder, 'tvshow.nfo'), lib_tools.nfo_url('tv', i))

			folder = lib_tools.make_path(self.library_folder, transtitle, year, season)
			lib_tools.create_folder(folder)
			lib_tools.write_file(os.path.join(folder, lib_tools.legal_filename('%s S%02dE%02d' % (transtitle, int(season), int(episode))) + '.strm'), content)
		except:
			log_utils.error()
			pass


class libepisodes:
	def __init__(self):
		self.library_folder = os.path.join(control.transPath(control.setting('library.tv')),'')

		self.library_setting = control.setting('library.update') or 'true'
		self.include_unknown = control.setting('library.include_unknown') or 'true'
		self.property = '%s_service_property' % control.addonInfo('name').lower()

		self.datetime = (datetime.datetime.utcnow() - datetime.timedelta(hours = 5))
		if control.setting('library.importdelay') != 'true':
			self.date = self.datetime.strftime('%Y%m%d')
		else:
			self.date = (self.datetime - datetime.timedelta(hours = 24)).strftime('%Y%m%d')

		self.infoDialog = False


	def update(self, query=None, info='true'):
		if query is not None:
			control.idle()

		if not lib_tools.ckKodiSources():
			return

		try:
			items = []
			season, episode = [], []
			show = [os.path.join(self.library_folder, i) for i in control.listDir(self.library_folder)[0]]

			for s in show:
				try:
					season += [os.path.join(s, i) for i in control.listDir(s)[0]]
				except:
					pass

			for s in season:
				try:
					episode.append([os.path.join(s, i) for i in control.listDir(s)[1] if i.endswith('.strm')][-1])
				except:
					pass

			for file in episode:
				try:
					file = control.openFile(file)
					read = file.read()
					read = read.encode('utf-8')
					file.close()

					if not read.startswith(sys.argv[0]):
						continue

					params = dict(urlparse.parse_qsl(read.replace('?','')))

					try:
						tvshowtitle = params['tvshowtitle']
					except:
						tvshowtitle = None

					try:
						tvshowtitle = params['show']
					except:
						pass

					if tvshowtitle is None or tvshowtitle == '':
						continue

					year, imdb, tvdb = params['year'], params['imdb'], params['tvdb']
					years = (year, str(int(year)+1), str(int(year)-1))

					imdb = 'tt' + re.sub('[^0-9]', '', str(imdb))
					tmdb = params.get('tmdb', '0')

					items.append({'tvshowtitle': tvshowtitle, 'year': year, 'imdb': imdb, 'tmdb': tmdb, 'tvdb': tvdb})
				except:
					pass

			items = [i for x, i in enumerate(items) if i not in items[x + 1:]]

			if len(items) == 0:
				return
		except:
			log_utils.error()
			return

		try:
			# lib = control.jsonrpc('{"jsonrpc": "2.0", "method": "VideoLibrary.GetTVShows", "params": {"properties": ["imdbnumber", "title", "year"]}, "id": 1 }')
			lib = control.jsonrpc('{"jsonrpc": "2.0", "method": "VideoLibrary.GetTVShows", "params": {"filter":{"or": [{"field": "year", "operator": "is", "value": "%s"}, {"field": "year", "operator": "is", "value": "%s"}, {"field": "year", "operator": "is", "value": "%s"}]}, "properties": ["imdbnumber", "title"]}, "id": 1}' % years)
			lib = unicode(lib, 'utf-8', errors='ignore')
			lib = json.loads(lib)['result']['tvshows']
		except:
			log_utils.error()
			return
 
		if info == 'true' and not control.condVisibility('Window.IsVisible(infodialog)') and not control.condVisibility('Player.HasVideo'):
			control.notification(title = 'default', message = 32553, icon = 'default', time = 10000000, sound = notificationSound)
			self.infoDialog = True

		try:
			control.makeFile(control.dataPath)
			dbcon = database.connect(control.libcacheFile)
			dbcur = dbcon.cursor()
			dbcur.execute("CREATE TABLE IF NOT EXISTS tvshows (""id TEXT, ""items TEXT, ""UNIQUE(id)"");")
			dbcur.connection.commit()
		except:
			log_utils.error()
			return

		from resources.lib.menus import episodes
		files_added = 0

		# __init__ doesn't get called from services so self.date never gets updated and new episodes are not added to the library
		self.datetime = (datetime.datetime.utcnow() - datetime.timedelta(hours = 5))
		if control.setting('library.importdelay') != 'true':
			self.date = self.datetime.strftime('%Y%m%d')
		else:
			self.date = (self.datetime - datetime.timedelta(hours = 24)).strftime('%Y%m%d')

		for item in items:
			it = None

			if xbmc.abortRequested is True:
				return sys.exit()

			try:
				dbcur.execute("SELECT * FROM tvshows WHERE id = '%s'" % item['tvdb'])
				fetch = dbcur.fetchone()
				if fetch is not None:
					it = eval(fetch[1].encode('utf-8'))
			except:
				log_utils.error()
				pass

			try:
				if it is not None:
					continue

				it = episodes.Episodes().get(item['tvshowtitle'], item['year'], item['imdb'], item['tvdb'], idx = False)

				status = it[0]['status'].lower()

				it = [{'title': i['title'], 'year': i['year'], 'imdb': i['imdb'], 'tvdb': i['tvdb'], 'season': i['season'], 'episode': i['episode'], 'tvshowtitle': i['tvshowtitle'], 'premiered': i['premiered']} for i in it]

				# if status == 'continuing':
					# continue

				dbcur.execute("INSERT INTO tvshows Values (?, ?)", (item['tvdb'], repr(it)))
				dbcur.connection.commit()
			except:
				log_utils.error()
				pass

			try:
				id = [item['imdb'], item['tvdb']]

				if item['tmdb'] != '0':
					id += [item['tmdb']]

				ep = [x['title'].encode('utf-8') for x in lib if str(x['imdbnumber']) in id or (x['title'].encode('utf-8') == item['tvshowtitle'] and str(x['year']) == item['year'])][0]
				ep = control.jsonrpc('{"jsonrpc": "2.0", "method": "VideoLibrary.GetEpisodes", "params": {"filter":{"and": [{"field": "tvshow", "operator": "is", "value": "%s"}]}, "properties": ["season", "episode"]}, "id": 1}' % ep)
				 # ep = control.jsonrpc('{"jsonrpc": "2.0", "method": "VideoLibrary.GetEpisodes", "params": {"filter":{"and": [{"field": "season", "operator": "is", "value": "%s"}, {"field": "episode", "operator": "is", "value": "%s"}]}, "properties": ["file"], "tvshowid": %s }, "id": 1}' % (str(season), str(episode), str(results['tvshowid'])))

				ep = unicode(ep, 'utf-8', errors = 'ignore')
				ep = json.loads(ep).get('result', {}).get('episodes', {})
				ep = [{'season': int(i['season']), 'episode': int(i['episode'])} for i in ep]
				ep = sorted(ep, key = lambda x: (x['season'], x['episode']))[-1]

				num = [x for x,y in enumerate(it) if str(y['season']) == str(ep['season']) and str(y['episode']) == str(ep['episode'])][-1]

				it = [y for x,y in enumerate(it) if x > num]

				if len(it) == 0:
					continue
			except:
				log_utils.error()
				continue

			for i in it:
				try:
					if xbmc.abortRequested is True:
						return sys.exit()

					premiered = i.get('premiered', '0')

					# Show Season Special(Season0).
					if int(i['season']) == 0 and control.setting('tv.specials') == 'false':
						continue

					# Show Unaired items.
					if status.lower() == 'ended':
						pass
					elif premiered == '0':
						continue
					elif int(re.sub('[^0-9]', '', str(premiered))) > int(re.sub('[^0-9]', '', str(self.date))):
						unaired = 'true'
						if self.showunaired != 'true':
							continue

					libtvshows().strmFile(i)
					files_added += 1
				except:
					log_utils.error()
					pass

		dbcon.close()

		if self.infoDialog is True:
			control.notification(title = 'default', message = 32554, icon = 'default', time = 1, sound = notificationSound)

		if self.library_setting == 'true' and not control.condVisibility('Library.IsScanningVideo') and files_added > 0:
			control.execute('UpdateLibrary(video)')


	def service(self):
		try:
			lib_tools.create_folder(os.path.join(control.transPath(control.setting('library.movie')), ''))
			lib_tools.create_folder(os.path.join(control.transPath(control.setting('library.tv')), ''))
		except:
			pass

		try:
			control.makeFile(control.dataPath)
			dbcon = database.connect(control.libcacheFile)
			dbcur = dbcon.cursor()
			dbcur.execute("CREATE TABLE IF NOT EXISTS service (""setting TEXT, ""value TEXT, ""UNIQUE(setting)"");")
			dbcur.connection.commit()

			dbcur.execute("SELECT * FROM service WHERE setting = 'last_run'")

			fetch = dbcur.fetchone()
			if fetch is None:
				serviceProperty = "1970-01-01 23:59:00.000000"
				dbcur.execute("INSERT INTO service Values (?, ?)", ('last_run', serviceProperty))
				dbcur.connection.commit()
			else:
				serviceProperty = str(fetch[1])
			dbcon.close()

		except:
			try:
				return dbcon.close()
			except:
				return

		try:
			control.window.setProperty(self.property, serviceProperty)
		except:
			return

		while not xbmc.abortRequested:
			try:
				serviceProperty = control.window.getProperty(self.property)

				t1 = datetime.timedelta(hours=6)
				t2 = datetime.datetime.strptime(serviceProperty, '%Y-%m-%d %H:%M:%S.%f')
				t3 = datetime.datetime.now()

				check = abs(t3 - t2) > t1
				if check is False:
					raise Exception()

				if (control.player.isPlaying() or control.condVisibility('Library.IsScanningVideo')):
					raise Exception()

				serviceProperty = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')

				control.window.setProperty(self.property, serviceProperty)

				try:
					dbcon = database.connect(control.libcacheFile)
					dbcur = dbcon.cursor()
					dbcur.execute("CREATE TABLE IF NOT EXISTS service (""setting TEXT, ""value TEXT, ""UNIQUE(setting)"");")
					dbcur.execute("DELETE FROM service WHERE setting = 'last_run'")
					dbcur.execute("INSERT INTO service Values (?, ?)", ('last_run', serviceProperty))
					dbcur.connection.commit()
					dbcon.close()
				except:
					try:
						dbcon.close()
					except:
						pass

				if not control.setting('library.service.update') == 'true':
					raise Exception()

				info = control.setting('library.service.notification') or 'true'
				self.update(info=info)
			except:
				pass

			control.sleep(10000)
