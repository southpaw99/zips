# -*- coding: utf-8 -*-
"""
	Venom Add-on
"""

import re
import requests
from resources.lib.modules import control
from resources.lib.modules import cache
from resources.lib.modules import metacache
from resources.lib.modules import py_tools
from resources.lib.modules import workers
from resources.lib.modules import log_utils

API_key = control.setting('tmdb.api.key')
if API_key == '' or API_key is None:
	API_key = '3320855e65a9758297fec4f7c9717698'

disable_fanarttv = control.setting('disable.fanarttv')
base_link = 'https://api.themoviedb.org/3/'
tmdb_networks = base_link + 'discover/tv?api_key=%s&sort_by=popularity.desc&with_networks=%s&page=1' % (API_key, '%s')
poster_path = 'https://image.tmdb.org/t/p/w300'
fanart_path = 'https://image.tmdb.org/t/p/w1280'


def get_request(url):
	try:
		try:
			response = requests.get(url)
		except requests.exceptions.SSLError:
			response = requests.get(url, verify=False)
	except requests.exceptions.ConnectionError:
		control.notification(message=32024)
		return
	if '200' in str(response):
		return response.json()
	elif 'Retry-After' in response.headers:
		# API REQUESTS ARE BEING THROTTLED, INTRODUCE WAIT TIME (TMDb removed rate-limit on 12-6-20)
		throttleTime = response.headers['Retry-After']
		control.notification(message='TMDB Throttling Applied, Sleeping for %s seconds' % throttleTime)
		control.sleep((int(throttleTime) + 1) * 1000)
		return get_request(url)
	else:
		log_utils.log('Get request failed to TMDB URL: %s\n                       msg : TMDB Response: %s' %
			(url, response.text), __name__, log_utils.LOGDEBUG)
		return None


def userlists(url):
	try:
		result = get_request(url % API_key)
		items = result['results']
		next = ''
		list = []
	except: return

	try: # This is actual wrong but may not be used so look into 
		page = int(result['page'])
		total = int(result['total_pages'])
		if page >= total: raise Exception()
		if 'page=' not in url: raise Exception()
		next = '%s&page=%s' % (url.split('&page=', 1)[0], page+1)
	except: next = ''

	for item in items:
		media_type = item.get('list_type')
		name = item.get('name')
		list_id =  item.get('id')
		url = 'https://api.themoviedb.org/4/list/%s?api_key=%s&sort_by=%s&page=1' % (list_id, API_key, tmdb_sort())
		item = {'media_type': media_type, 'name': name, 'list_id': list_id, 'url': url, 'context': url, 'next': next}
		list.append(item)
	return list


def popular_people():
	url = '%s%s' % (base_link, 'person/popular?api_key=%s&language=en-US&page=1' % API_key)
	item = get_request(url)
	return item


def tmdb_sort():
	sort = int(control.setting('sort.movies.type'))
	tmdb_sort = 'original_order'
	if sort == 1: tmdb_sort = 'title'
	if sort in [2, 3]: tmdb_sort = 'vote_average'
	if sort in [4, 5, 6]: tmdb_sort = 'release_date'
	tmdb_sort_order = '.asc' if int(control.setting('sort.movies.order')) == 0 else '.desc'
	sort_string = tmdb_sort + tmdb_sort_order
	return sort_string


class Movies:
	def __init__(self):
		self.list = []
		self.meta = []
		self.lang = control.apiLanguage()['trakt']
		self.movie_link = base_link + 'movie/%s?api_key=%s&language=%s&append_to_response=credits,release_dates,videos,alternative_titles' % ('%s', API_key, self.lang)
###                                                                  other "append_to_response" options                     external_ids,images,content_ratings
		self.art_link = base_link + 'movie/%s/images?api_key=%s' % ('%s', API_key)
		self.external_ids = base_link + 'movie/%s/external_ids?api_key=%s' % ('%s', API_key)


	def tmdb_list(self, url):
		try:
			result = get_request(url % API_key)
			items = result['results']
		except: return

		self.list = [] ; sortList = []
		try:
			page = int(result['page'])
			total = int(result['total_pages'])
			if page >= total: raise Exception()
			if 'page=' not in url: raise Exception()
			next = '%s&page=%s' % (url.split('&page=', 1)[0], page+1)
		except: next = ''

		for item in items:
			try:
				values = {}
				values['mediatype'] = 'movie' 
				values['next'] = next 
				values['title'] = py_tools.ensure_str(item.get('title'))
				values['originaltitle'] = values['title'] 
				values['premiered'] = item.get('release_date', '0')
				try: values['year'] = str(values['premiered'][:4])
				except: values['year'] = '0'
				values['tmdb'] = str(item.get('id'))
				sortList.append(values['tmdb'])
				values['poster'] = '%s%s' % (poster_path, item['poster_path']) if item['poster_path'] else ''
				values['fanart'] = '%s%s' % (fanart_path, item['backdrop_path']) if item['backdrop_path'] else ''
				values['rating'] = str(item.get('vote_average', ''))
				values['votes'] = str(format(int(item.get('vote_count', '0')),',d'))
				values['plot'] = py_tools.ensure_str(item.get('overview'))
				values['metacache'] = False 
				self.list.append(values)
			except:
				log_utils.error()

		def items_list(i):
			if i['metacache']: return
			try:
				# values = i
				# log_utils.log('values = %s' % values)

				next, title, originaltitle, year, tmdb, poster, fanart, premiered, rating, votes, plot = \
					i['next'], i['title'], i['originaltitle'], i['year'], i['tmdb'], i['poster'], i['fanart'], i['premiered'], i['rating'], i['votes'], i['plot']
				url = self.movie_link % tmdb
				item = get_request(url)

				imdb = item.get('imdb_id')
				# try: studio = item.get('production_companies', None)[0]['name'] # Silvo seems to use "studio" icons in place of "thumb" for movies in list view
				# except: studio = ''

				genre = []
				for x in item['genres']: genre.append(x.get('name'))
				if genre == []: genre = 'NA'

				duration = str(item.get('runtime', '0'))
				if duration == 'None': duration = '0'

				try:
					rel_info = [x for x in item['release_dates']['results'] if x['iso_3166_1'] == 'US'][0]
					mpaa = 'NR'
					for cert in rel_info.get('release_dates', {}):
						if cert['certification']: # loop thru all keys
							mpaa = cert['certification']
							break
				except: mpaa = 'NR'

				crew = item.get('credits', {}).get('crew')
				try: director = ', '.join([d['name'] for d in [x for x in crew if x['job'] == 'Director']])
				except: director = ''
				try: writer = ', '.join([w['name'] for w in [y for y in crew if y['job'] in ['Writer', 'Screenplay', 'Author', 'Novel']]])
				except: writer = ''

				castandart = []
				for person in item['credits']['cast']:
					try: castandart.append({'name': person['name'], 'role': person['character'], 'thumbnail': ((poster_path + person.get('profile_path')) if person.get('profile_path') is not None else '')})
					except: castandart = []
					if len(castandart) == 150: break

				try:
					trailer = [x for x in item['videos']['results'] if x['site'] == 'YouTube' and x['type'] in ('Trailer', 'Teaser')][0]['key']
					trailer = control.trailer % trailer
				except: trailer = ''

				values = {'content': 'movie', 'title': title, 'originaltitle': originaltitle, 'year': year, 'premiered': premiered,
							'genre': genre, 'duration': duration, 'rating': rating, 'votes': votes, 'mpaa': mpaa, 'director': director, 'writer': writer,
							'castandart': castandart, 'plot': plot, 'code': tmdb, 'imdb': imdb, 'tmdb': tmdb, 'tvdb': '0', 'poster': poster,
							'poster2': '0', 'poster3': '0', 'banner': '0', 'fanart': fanart, 'fanart2': '0', 'fanart3': '0', 'clearlogo': '0', 'clearart': '0',
							'landscape': fanart, 'mediatype': 'movie', 'trailer': trailer, 'metacache': False, 'next': next}
				meta = {'imdb': imdb, 'tmdb': tmdb, 'tvdb': '0', 'lang': self.lang, 'user': API_key, 'item': values}

				if disable_fanarttv != 'true':
					from resources.lib.indexers import fanarttv
					extended_art = cache.get(fanarttv.get_movie_art, 168, imdb, tmdb)
					if extended_art:
						values.update(extended_art)
						meta.update(values)

				values = dict((k,v) for k, v in control.iteritems(values) if v and v != '0')
				for i in range(0, len(self.list)):
					if str(self.list[i]['tmdb']) == str(tmdb):
						self.list[i].update(values)

				if 'next' in meta.get('item'): del meta['item']['next']

				self.meta.append(meta)
				metacache.insert(self.meta)
			except:
				log_utils.error()

		self.list = metacache.fetch(self.list, self.lang, API_key)
		items = self.list[:len(self.list)]

		threads = []
		for i in items:
			threads.append(workers.Thread(items_list, i))
		[i.start() for i in threads]
		[i.join() for i in threads]

		sorted_list = []
		for i in sortList:
			sorted_list += [item for item in self.list if str(item['tmdb']) == str(i)]
		return sorted_list


	def tmdb_collections_list(self, url):
		try:
			result = get_request(url)
			if '/3/' in url: items = result['items']
			else: items = result['results']
		except: return

		self.list = []
		try:
			page = int(result['page'])
			total = int(result['total_pages'])
			if page >= total: raise Exception()
			if 'page=' not in url: raise Exception()
			next = '%s&page=%s' % (url.split('&page=', 1)[0], page+1)
		except: next = ''

		for item in items:
			try:
				values = {}
				values['next'] = next 
				media_type = item.get('media_type', '0')
				if media_type == 'tv': continue
				values['mediatype'] = 'movie' 
				values['title'] = py_tools.ensure_str(item.get('title'))
				values['originaltitle'] = values['title'] 
				values['premiered'] = item.get('release_date', '0')
				try: values['year'] = str(values['premiered'][:4])
				except: values['year'] = '0'
				values['tmdb'] = str(item.get('id'))
				values['poster'] = '%s%s' % (poster_path, item['poster_path']) if item['poster_path'] else ''
				values['fanart'] = '%s%s' % (fanart_path, item['backdrop_path']) if item['backdrop_path'] else ''
				values['rating'] = str(item.get('vote_average', ''))
				values['votes'] = str(format(int(item.get('vote_count', '0')),',d'))
				values['plot'] = py_tools.ensure_str(item.get('overview'))
				values['metacache'] = False 
				self.list.append(values)
			except:
				log_utils.error()

		def items_list(i):
			if i['metacache']: return
			try:
				# values = i
				next, title, originaltitle, year, tmdb, poster, fanart, premiered, rating, votes, plot = \
					i['next'], i['title'], i['originaltitle'], i['year'], i['tmdb'], i['poster'], i['fanart'], i['premiered'], i['rating'], i['votes'], i['plot']
				url = self.movie_link % tmdb
				item = get_request(url)

				imdb = item.get('imdb_id')
				# try: studio = item.get('production_companies', None)[0]['name'] # Silvo seems to use "studio" icons in place of "thumb" for movies in list view
				# except: studio = ''

				genre = []
				for x in item['genres']: genre.append(x.get('name'))
				if genre == []: genre = 'NA'

				duration = str(item.get('runtime', '0'))
				if duration == 'None': duration = '0'

				try:
					rel_info = [x for x in item['release_dates']['results'] if x['iso_3166_1'] == 'US'][0]
					mpaa = 'NR'
					for cert in rel_info.get('release_dates', {}):
						if cert['certification']: # loop thru all keys
							mpaa = cert['certification']
							break
				except: mpaa = 'NR'

				crew = item.get('credits', {}).get('crew')
				try: director = ', '.join([d['name'] for d in [x for x in crew if x['job'] == 'Director']])
				except: director = ''
				try: writer = ', '.join([w['name'] for w in [y for y in crew if y['job'] in ['Writer', 'Screenplay', 'Author', 'Novel']]])
				except: writer = ''

				castandart = []
				for person in item['credits']['cast']:
					try: castandart.append({'name': person['name'], 'role': person['character'], 'thumbnail': ((poster_path + person.get('profile_path')) if person.get('profile_path') is not None else '')})
					except: castandart = []
					if len(castandart) == 150: break

				try:
					trailer = [x for x in item['videos']['results'] if x['site'] == 'YouTube' and x['type'] in ('Trailer', 'Teaser')][0]['key']
					trailer = control.trailer % trailer
				except: trailer = ''

				values = {'content': 'movie', 'title': title, 'originaltitle': originaltitle, 'year': year, 'premiered': premiered,
							'genre': genre, 'duration': duration, 'rating': rating, 'votes': votes, 'mpaa': mpaa, 'director': director, 'writer': writer,
							'castandart': castandart, 'plot': plot, 'code': tmdb, 'imdb': imdb, 'tmdb': tmdb, 'tvdb': '0', 'poster': poster,
							'poster2': '0', 'poster3': '0', 'banner': '0', 'fanart': fanart, 'fanart2': '0', 'fanart3': '0', 'clearlogo': '0', 'clearart': '0',
							'landscape': fanart, 'trailer': trailer, 'metacache': False, 'next': next}
				meta = {'imdb': imdb, 'tmdb': tmdb, 'tvdb': '0', 'lang': self.lang, 'user': API_key, 'item': values}

				if disable_fanarttv != 'true':
					from resources.lib.indexers import fanarttv
					extended_art = cache.get(fanarttv.get_movie_art, 168, imdb, tmdb)
					if extended_art:
						values.update(extended_art)
						meta.update(values)

				values = dict((k,v) for k, v in control.iteritems(values) if v and v != '0')
				for i in range(0, len(self.list)):
					if str(self.list[i]['tmdb']) == str(tmdb):
						self.list[i].update(values)

				if 'next' in meta.get('item'): del meta['item']['next']

				self.meta.append(meta)
				metacache.insert(self.meta)
			except:
				log_utils.error()

		self.list = metacache.fetch(self.list, self.lang, API_key)
		items = self.list[:len(self.list)]

		threads = []
		for i in items:
			threads.append(workers.Thread(items_list, i))
		[i.start() for i in threads]
		[i.join() for i in threads]
		return self.list


	def get_details(self, tmdb, imdb):
		if not tmdb and not imdb: return
		try:
			result = None
			url = self.movie_link % tmdb
			# result = get_request(url)
			result = cache.get(get_request, 96, url)
			if not result:
				# if imdb != '0': result = get_request(self.movie_link % imdb) # api claims int rq'd.  But imdb_id works for movies but not looking like it does for shows
				if imdb != '0': result = cache.get(get_request, 96, self.movie_link % imdb) # api claims int rq'd.  But imdb_id works for movies but not looking like it does for shows
		except:
			log_utils.error()
		return result


	def get_art(self, tmdb):
		if not tmdb or tmdb == '0': return None
		url = self.art_link % tmdb
		art3 = get_request(url)
		# art3 = cache.get(get_request, 96, url)
		if not art3: return None
		try:
			poster3 = self.parse_art(art3['posters'])
			poster3 = poster_path + poster3
		except: poster3 = ''
		try:
			fanart3 = self.parse_art(art3['backdrops'])
			fanart3 = fanart_path + fanart3
		except: fanart3 = ''
		extended_art = {'extended': True, 'poster3': poster3, 'fanart3': fanart3}
		return extended_art


	def parse_art(self, img):
		if not img: return None
		try:
			ret_img = [(x['file_path'], x['vote_average']) for x in img if any(value == x.get('iso_639_1') for value in [self.lang, 'null', '', None])]
			if not ret_img: ret_img = [(x['file_path'], x['vote_average']) for x in img]
			if not ret_img: return None
			if len(ret_img) >1:
				ret_img = sorted(ret_img, key=lambda x: int(x[1]), reverse=True)
			ret_img = [x[0] for x in ret_img][0]
		except:
			log_utils.error()
			return None
		return ret_img


	def get_credits(self, tmdb):
		if API_key == '' or (not tmdb or tmdb == '0' or tmdb == 'None'): return None
		url = base_link + 'movie/%s/credits?api_key=%s' % ('%s', API_key)
		people = get_request(url % tmdb)
		if not people: return None
		return people


	def get_external_ids(self, tmdb, imdb): # api claims int rq'd.  But imdb_id works for movies but not looking like it does for shows
		result = None
		if tmdb and tmdb != '0': result = cache.get(get_request, 96, self.external_ids % tmdb)
		if not result:
			if imdb and imdb != '0': result = cache.get(get_request, 96, self.external_ids % imdb)
		return result


	def IdLookup(self, imdb):
		try:
			result = None
			find_url = base_link + 'find/%s?api_key=%s&external_source=%s'
			if imdb and imdb != '0':
				url = find_url % (imdb, API_key, 'imdb_id')
				result = cache.get(get_request, 96, url)['movie_results'][0]
		except:
			log_utils.error()
		return result


class TVshows:
	def __init__(self):
		self.list = []
		self.meta = []
		self.lang = control.apiLanguage()['tvdb']
		self.show_link = base_link + 'tv/%s?api_key=%s&language=%s&append_to_response=credits,content_ratings,external_ids,alternative_titles,videos' % ('%s', API_key, self.lang)
		self.art_link = base_link + 'tv/%s/images?api_key=%s' % ('%s', API_key)
		self.tvdb_key = control.setting('tvdb.api.key')
		self.imdb_user = control.setting('imdb.user').replace('ur', '')
		self.user = str(self.imdb_user) + str(self.tvdb_key)


	def tmdb_list(self, url):
		try:
			result = get_request(url % API_key)
			items = result['results']
		except: return

		self.list = [] ; sortList = []
		try:
			page = int(result['page'])
			total = int(result['total_pages'])
			if page >= total: raise Exception()
			if 'page=' not in url: raise Exception()
			next = '%s&page=%s' % (url.split('&page=', 1)[0], page+1)
		except: next = ''

		for item in items:
			try:
				values = {}
				values['mediatype'] = 'tvshow' 
				values['next'] = next 
				values['title'] = py_tools.ensure_str(item.get('name'))
				values['originaltitle'] = values['title'] 
				values['tvshowtitle'] = values['title'] 
				values['premiered'] = item.get('first_air_date', '0')
				try: values['year'] = str(values['premiered'][:4])
				except: values['year'] = '0'
				values['tmdb'] = str(item.get('id'))
				sortList.append(values['tmdb'])
				values['poster'] = '%s%s' % (poster_path, item['poster_path']) if item['poster_path'] else ''
				values['fanart'] = '%s%s' % (fanart_path, item['backdrop_path']) if item['backdrop_path'] else ''
				values['rating'] = str(item.get('vote_average', ''))
				values['votes'] = str(format(int(item.get('vote_count', '0')),',d'))
				values['plot'] = py_tools.ensure_str(item.get('overview'))
				values['metacache'] = False 
				self.list.append(values)
			except:
				log_utils.error()

		def items_list(i):
			if i['metacache']: return
			try:
				# values = i
				next, title, year, tmdb, poster, fanart, premiered, rating, votes, plot = \
					i['next'], i['title'], i['year'], i['tmdb'], i['poster'], i['fanart'], i['premiered'], i['rating'], i['votes'], i['plot']
				url = self.show_link % tmdb
				item = get_request(url)

				tvdb = str(item.get('external_ids').get('tvdb_id'))
				imdb = item.get('external_ids').get('imdb_id')

				genre = []
				for x in item['genres']: genre.append(x.get('name'))
				if genre == []: genre = 'NA'

				try: duration = min(item['episode_run_time']) # work towards changing all to be "* 60"
				except: duration = ''

				try: mpaa = [x['rating'] for x in item['content_ratings']['results'] if x['iso_3166_1'] == 'US'][0]
				except: 
					try: mpaa = item['content_ratings'][0]['rating']
					except: mpaa = 'NR'

				status = item.get('status', '0')

				try: studio = item.get('networks', None)[0]['name']
				except: studio = '0'

				try: total_seasons = int(item.get('number_of_seasons', ''))
				except: total_seasons = 0
				total_episodes = item.get('number_of_episodes')
				counts = self.tmdb_seasonCountParse(item.get('seasons'))
				seasons = item.get('seasons')

				crew = item.get('credits', {}).get('crew')
				try: director = ', '.join([d['name'] for d in [x for x in crew if x['job'] == 'Director']])
				except: director = ''
				try: writer = ', '.join([w['name'] for w in [y for y in crew if y['job'] == 'Writer']]) # movies also contains "screenplay", "author", "novel". See if any apply for shows
				except: writer = ''

				castandart = []
				for person in item['credits']['cast']:
					try: castandart.append({'name': person['name'], 'role': person['character'], 'thumbnail': ((poster_path + person.get('profile_path')) if person.get('profile_path') is not None else '')})
					except: castandart = []
					if len(castandart) == 150: break

				try:
					trailer = [x for x in item['videos']['results'] if x['site'] == 'YouTube' and x['type'] in ('Trailer', 'Teaser')][0]['key']
					trailer = control.trailer % trailer
				except: trailer = ''

				values = {'content': 'tvshow', 'title': title, 'originaltitle': title, 'year': year, 'premiered': premiered, 'studio': studio, 'genre': genre, 'duration': duration, 'rating': rating,
								'votes': votes, 'mpaa': mpaa, 'status': status, 'director': director, 'writer': writer, 'castandart': castandart, 'plot': plot, 'code': tmdb, 'imdb': imdb,
								'tmdb': tmdb, 'tvdb': tvdb, 'poster': poster, 'poster2': '0', 'poster3': '0', 'banner': '0', 'banner2': '0', 'fanart': fanart, 'fanart2': '0', 'fanart3': '0', 'clearlogo': '0', 'clearart': '0',
								'landscape': fanart, 'total_seasons': total_seasons, 'total_episodes': total_episodes, 'counts': counts, 'seasons': seasons, 'trailer': trailer, 'metacache': False, 'next': next}
				meta = {'imdb': imdb, 'tmdb': tmdb, 'tvdb': tvdb, 'lang': self.lang, 'user': self.user, 'item': values}

				if disable_fanarttv != 'true':
					from resources.lib.indexers import fanarttv
					extended_art = cache.get(fanarttv.get_tvshow_art, 168, tvdb)
					if extended_art:
						values.update(extended_art)
						meta.update(values)

				values = dict((k,v) for k, v in control.iteritems(values) if v and v != '0')
				for i in range(0, len(self.list)):
					if str(self.list[i]['tmdb']) == str(tmdb):
						self.list[i].update(values)
				if 'next' in meta.get('item'): del meta['item']['next']

				self.meta.append(meta)
				metacache.insert(self.meta)
			except:
				log_utils.error()

		self.list = metacache.fetch(self.list, self.lang, API_key)
		items = self.list[:len(self.list)]

		threads = []
		for i in items:
			threads.append(workers.Thread(items_list, i))
		[i.start() for i in threads]
		[i.join() for i in threads]

		sorted_list = []
		for i in sortList:
			sorted_list += [item for item in self.list if str(item['tmdb']) == str(i)]
		return sorted_list


	def tmdb_collections_list(self, url):
		try:
			result = get_request(url)
			if '/3/' in url: items = result['items']
			else: items = result['results']
		except: return

		self.list = []
		try:
			page = int(result['page'])
			total = int(result['total_pages'])
			if page >= total: raise Exception()
			if 'page=' not in url: raise Exception()
			next = '%s&page=%s' % (url.split('&page=', 1)[0], page+1)
		except: next = ''

		for item in items:
			try:
				values = {}
				values['next'] = next 
				media_type = item.get('media_type', '0')
				if media_type == 'movie': 	continue
				values['mediatype'] = 'tvshow' 
				values['title'] = py_tools.ensure_str(item.get('name'))
				values['originaltitle'] = values['title'] 
				values['tvshowtitle'] = values['title'] 
				values['premiered'] = item.get('first_air_date', '0')
				try: values['year'] = str(values['premiered'][:4])
				except: values['year'] = '0'
				values['tmdb'] = str(item.get('id'))
				values['poster'] = '%s%s' % (poster_path, item['poster_path']) if item['poster_path'] else ''
				values['fanart'] = '%s%s' % (fanart_path, item['backdrop_path']) if item['backdrop_path'] else ''
				values['rating'] = str(item.get('vote_average', ''))
				values['votes'] = str(format(int(item.get('vote_count', '0')),',d'))
				values['plot'] = py_tools.ensure_str(item.get('overview'))
				values['metacache'] = False 
				self.list.append(values)
			except:
				log_utils.error()

		def items_list(i):
			if i['metacache']: return
			try:
				# values = i
				next, title, year, tmdb, poster, fanart, premiered, rating, votes, plot = \
					i['next'], i['title'], i['year'], i['tmdb'], i['poster'], i['fanart'], i['premiered'], i['rating'], i['votes'], i['plot']
				url = self.show_link % tmdb
				item = get_request(url)

				tvdb = str(item.get('external_ids').get('tvdb_id'))
				imdb = item.get('external_ids').get('imdb_id')

				genre = []
				for x in item['genres']: genre.append(x.get('name'))
				if genre == []: genre = 'NA'

				try: duration = min(item['episode_run_time']) # work towards changing all to be "* 60"
				except: duration = ''

				try: mpaa = [x['rating'] for x in item['content_ratings']['results'] if x['iso_3166_1'] == 'US'][0]
				except: 
					try: mpaa = item['content_ratings'][0]['rating']
					except: mpaa = 'NR'

				status = item.get('status', '0')

				try: studio = item.get('networks', None)[0]['name']
				except: studio = '0'

				try: total_seasons = int(item.get('number_of_seasons', ''))
				except: total_seasons = 0
				total_episodes = item.get('number_of_episodes')
				counts = self.tmdb_seasonCountParse(item.get('seasons'))
				seasons = item.get('seasons')

				crew = item.get('credits', {}).get('crew')
				try: director = ', '.join([d['name'] for d in [x for x in crew if x['job'] == 'Director']])
				except: director = ''
				try: writer = ', '.join([w['name'] for w in [y for y in crew if y['job'] == 'Writer']]) # movies also contains "screenplay", "author", "novel". See if any apply for shows
				except: writer = ''

				castandart = []
				for person in item['credits']['cast']:
					try: castandart.append({'name': person['name'], 'role': person['character'], 'thumbnail': ((poster_path + person.get('poster_path')) if person.get('poster_path') is not None else '')})
					except: castandart = []
					if len(castandart) == 150: break

				try:
					trailer = [x for x in item['videos']['results'] if x['site'] == 'YouTube' and x['type'] in ('Trailer', 'Teaser')][0]['key']
					trailer = control.trailer % trailer
				except: trailer = ''

# what's content used for here?
				values = {'content': 'tvshow', 'title': title, 'originaltitle': title, 'year': year, 'premiered': premiered, 'studio': studio, 'genre': genre, 'duration': duration, 'rating': rating,
								'votes': votes, 'mpaa': mpaa, 'status': status, 'director': director, 'writer': writer, 'castandart': castandart, 'plot': plot, 'code': tmdb, 'imdb': imdb,
								'tmdb': tmdb, 'tvdb': tvdb, 'poster': poster, 'poster2': '0', 'poster3': '0', 'banner': '0', 'banner2': '0', 'fanart': fanart, 'fanart2': '0', 'fanart3': '0', 'clearlogo': '0', 'clearart': '0',
								'landscape': fanart, 'total_seasons': total_seasons, 'total_episodes': total_episodes, 'counts': counts, 'seasons': seasons, 'trailer': trailer, 'metacache': False, 'next': next}
				meta = {'imdb': imdb, 'tmdb': tmdb, 'tvdb': tvdb, 'lang': self.lang, 'user': self.user, 'item': values}

				if disable_fanarttv != 'true':
					from resources.lib.indexers import fanarttv
					extended_art = cache.get(fanarttv.get_tvshow_art, 168, tvdb)
					if extended_art:
						values.update(extended_art)
						meta.update(values)

				values = dict((k,v) for k, v in control.iteritems(values) if v and v != '0')
				for i in range(0, len(self.list)):
					if str(self.list[i]['tmdb']) == str(tmdb):
						self.list[i].update(values)
				if 'next' in meta.get('item'): del meta['item']['next']

				self.meta.append(meta)
				metacache.insert(self.meta)
			except:
				log_utils.error()

		self.list = metacache.fetch(self.list, self.lang, API_key)
		items = self.list[:len(self.list)]

		threads = []
		for i in items:
			threads.append(workers.Thread(items_list, i))
		[i.start() for i in threads]
		[i.join() for i in threads]
		return self.list


	def get_show_request(self, tmdb):
		if not tmdb or tmdb == '0': return None
		try:
			result = None
			url = self.show_link % tmdb
			result = get_request(url)
			# result = cache.get(get_request, 96, url)
		except:
			log_utils.error()
		return result


	def get_showSeasons_meta(self, tmdb): # builds seasons meta from show level request
		try:
			if not tmdb or tmdb == '0': return None
			result = self.get_show_request(tmdb)
			if not result: return
			meta = {}
		except:
			log_utils.error()
			return None
		try:
			meta['mediatype'] = 'tvshow'
			try: meta['fanart'] = fanart_path + result['backdrop_path']
			except: meta['fanart'] = ''

			try: meta['duration'] = min(result['episode_run_time']) # work towards changing all to be "* 60"
			except: meta['duration'] = ''

			meta['premiered'] = result.get('first_air_date', '0')
			try: meta['year'] = str(meta['premiered'][:4])
			except: meta['year'] = '0'

			meta['genre'] = ' / '.join([x['name'] for x in result.get('genres', {})]) or ''
			meta['tmdb'] = str(tmdb)
			meta['in_production'] = result.get('in_production')
			meta['last_air_date'] = result.get('last_air_date', '')
			# meta['last_episode_to_air'] = 
			meta['tvshowtitle'] = py_tools.ensure_str(result.get('name'))
			# meta['next_episode_to_air'] = 

			try: meta['studio'] = result.get('networks', {})[0].get('name')
			except: meta['studio'] = ''
			meta['total_episodes'] = result.get('number_of_episodes')
			meta['total_seasons'] = result.get('number_of_seasons')

			try: meta['origin_country'] = result.get('origin_country')[0]
			except: meta['origin_country'] = ''

			meta['original_language'] = result.get('original_language')
			meta['originaltitle'] = py_tools.ensure_str(result.get('original_name'))
			meta['plot'] = py_tools.ensure_str(result.get('overview'))
			# meta['?'] = result.get('popularity', '')

			try: meta['poster'] = poster_path + result['poster_path']
			except: meta['poster'] = ''

			meta['seasons'] = result.get('seasons')
			meta['spoken_languages'] = result.get('spoken_languages')
			meta['status'] = result.get('status')
			meta['tagline'] = result.get('tagline', '')
			meta['type'] = result.get('type')
			meta['rating'] = result.get('vote_average', '')
			meta['votes'] = result.get('vote_count', '')

			crew = result.get('credits', {}).get('crew')
			try: meta['director'] = ', '.join([d['name'] for d in [x for x in crew if x['job'] == 'Director']])
			except: meta['director'] = ''
			try: meta['writer'] = ', '.join([w['name'] for w in [y for y in crew if y['job'] == 'Writer']]) # movies also contains "screenplay", "author", "novel". See if any apply for shows
			except: meta['writer'] = ''

			meta['castandart'] = []
			for person in result['credits']['cast']:
				try: meta['castandart'].append({'name': person['name'], 'role': person['character'], 'thumbnail': ((poster_path + person.get('profile_path')) if person.get('profile_path') is not None else '')})
				except: meta['castandart'] = []
				if len(meta['castandart']) == 150: break

			try: meta['mpaa'] = [x['rating'] for x in result['content_ratings']['results'] if x['iso_3166_1'] == 'US'][0]
			except: 
				try: meta['mpaa'] = result['content_ratings'][0]['rating']
				except: meta['mpaa'] = 'NR'

			meta['imdb'] = str(result.get('external_ids', {}).get('imdb_id'))
			meta['imdbnumber'] = meta['imdb']
			meta['tvdb'] = str(result.get('external_ids', {}).get('tvdb_id'))

			# make aliases match what trakt returns in sources module for title checking scrape results
			try: meta['aliases'] = [{'title': x['title'], 'country': x['iso_3166_1'].lower()} for x in result.get('alternative_titles', {}).get('results') if x.get('iso_3166_1').lower() in ('us', 'uk', 'gb')]
			except: meta['aliases'] = []

			try:
				meta['trailer'] = [x for x in result['videos']['results'] if x['site'] == 'YouTube' and x['type'] in ('Trailer', 'Teaser')][0]['key']
				meta['trailer'] = control.trailer % meta['trailer']
			except: meta['trailer'] = ''
			meta['banner'] = '' # not available from TMDb
		except:
			log_utils.error()
		return meta


	def get_season_request(self, tmdb, season):
		if not tmdb or tmdb == '0': return None
		try:
			result = None
			url = '%s%s' % (base_link, 'tv/%s/season/%s?api_key=%s&language=%s,en-US&append_to_response=credits' % (tmdb, season, API_key, self.lang))
# https://api.themoviedb.org/3/tv/1399/season/1?api_key=3320855e65a9758297fec4f7c9717698&language=en,en-US&append_to_response=credits%2cimages&include_image_language=en,null
			result = get_request(url)
			# result = cache.get(get_request, 96, url)
		except:
			log_utils.error()
		return result


	def get_seasonEpisodes_meta(self, tmdb, season): # builds episodes meta from "/season/?" request
		try:
			if not tmdb or tmdb == '0': return None
			result = self.get_season_request(tmdb, season)
			if not result: return
			meta = {}
		except:
			log_utils.error()
			return None
		try:
			meta['premiered'] = result['air_date'] # season level Information seems no longer available in 19
			episodes = []
			for episode in result['episodes']:
				episode_meta = {}
				episode_meta['mediatype'] = 'episode'
				episode_meta['premiered'] = episode['air_date']
				try: meta['year'] = str(meta['premiered'][:4])
				except: meta['year'] = '0'
				episode_meta['episode'] = episode['episode_number']
				crew = episode.get('crew')
				try: episode_meta['director'] = ', '.join([d['name'] for d in [x for x in crew if x['job'] == 'Director']])
				except: episode_meta['director'] = ''
				try: episode_meta['writer'] = ', '.join([w['name'] for w in [y for y in crew if y['job'] == 'Writer']]) # movies also contains "screenplay", "author", "novel". See if any apply for shows
				except: episode_meta['writer'] = ''
				episode_meta['title'] = episode['name']
				episode_meta['plot'] = episode['overview']
				episode_meta['code'] = episode['production_code']
				episode_meta['season'] = episode['season_number']
				try: episode_meta['thumb'] = fanart_path + episode['still_path'] or '0'
				except: episode_meta['thumb'] = '0'
				episode_meta['rating'] = episode['vote_average']
				episode_meta['votes'] = episode['vote_count']
				episodes.append(episode_meta)
				# check if episodeIDS still needed by UpNext
				# values = {'tvshowyear': year, 'episodeIDS': episodeIDS}

			meta['seasoncount'] = len(result.get('episodes')) #seasoncount = number of episodes for given season
			# meta['tvseasontitle'] = result['name'] # seasontitle ?
			meta['plot'] = py_tools.ensure_str(result.get('overview')) # season level Information seems no longer available in 19

			meta['tmdb'] = tmdb
			try: meta['poster'] = poster_path + result['poster_path']
			except: meta['poster'] = ''
			meta['season_poster'] = meta['poster']
			meta['season'] = result.get('season_number')
			meta['castandart'] = []
			for person in result['credits']['cast']:
				try: meta['castandart'].append({'name': person['name'], 'role': person['character'], 'thumbnail': ((poster_path + person.get('profile_path')) if person.get('profile_path') is not None else '')})
				except: meta['castandart'] = []
				if len(meta['castandart']) == 150: break
			meta['banner'] = '' # not available from TMDb
			meta['episodes'] = episodes
		except:
			log_utils.error()
		return meta

		# episodeIDS = {}
		# if control.setting('enable.upnext') == 'true':
			# episodeIDS = cache.get(trakt.getEpisodeSummary, 96, imdb, season, episode, full=False) or {}
			# if episodeIDS != {}:
				# episodeIDS = episodeIDS.get('ids', {})


	def get_episodes_request(self, tmdb, season, episode): # Don't think I'll use this at all
		if not tmdb or tmdb == '0': return None
		try:
			result = None
			url = '%s%s' % (base_link, 'tv/%s/season/%s/episode/%s?api_key=%s&language=%s&append_to_response=credits' % (tmdb, season, episode, API_key, self.lang))
			result = get_request(url)
			# result = cache.get(get_request, 96, url)
		except:
			log_utils.error()
		return result


	def tmdb_seasonCountParse(self, seasons): # move this to tmdb module so "TVshows().tmdb_list()" can parse at show level and "metacache.insert()"
		counts = {}
		for s in seasons:
			season = str(s.get('season_number'))
			counts[season] = s.get('episode_count')
		return counts


	def get_art(self, tmdb):
		if not tmdb or tmdb == '0': return None
		url = self.art_link % tmdb
		art3 = get_request(url)
		# art3 = cache.get(get_request, 96, url)
		if not art3: return None
		try:
			poster3 = self.parse_art(art3['posters'])
			poster3 = poster_path + poster3
		except: poster3 = ''
		try:
			fanart3 = self.parse_art(art3['backdrops'])
			fanart3 = fanart_path + fanart3
		except: fanart3 = ''
		extended_art = {'extended': True, 'poster3': poster3, 'fanart3': fanart3}
		return extended_art


	def parse_art(self, img):
		if not img: return None
		try:
			ret_img = [(x['file_path'], x['vote_average']) for x in img if any(value == x.get('iso_639_1') for value in [self.lang, 'null', '', None])]
			if not ret_img: ret_img = [(x['file_path'], x['vote_average']) for x in img]
			if not ret_img: return None
			if len(ret_img) >1:
				ret_img = sorted(ret_img, key=lambda x: int(x[1]), reverse=True)
			ret_img = [x[0] for x in ret_img][0]
		except:
			log_utils.error()
			return None
		return ret_img


	def get_credits(self, tmdb):
		if not tmdb or tmdb == '0': return None
		try:
			result = None
			url = base_link + 'tv/%s/credits?api_key=%s' % (tmdb, API_key)
			# result = get_request(url)
			result = cache.get(get_request, 96, url)
		except:
			log_utils.error()
		return result


	def get_external_ids(self, tmdb):
		if not tmdb or tmdb == '0': return None
		try:
			result = None
			url = base_link + 'tv/%s/external_ids?api_key=%s' % (tmdb, API_key)
			# result = get_request(url)
			result = cache.get(get_request, 96, url)
		except:
			log_utils.error()
		return result


	def IdLookup(self, imdb, tvdb=None):
		try:
			result = None
			find_url = base_link + 'find/%s?api_key=%s&external_source=%s'
			if imdb and imdb != '0':
				url = find_url % (imdb, API_key, 'imdb_id')
				try: result = cache.get(get_request, 96, url)['tv_results'][0]
				except: pass
			if tvdb and tvdb != '0' and not result:
				url = find_url % (tvdb, API_key, 'tvdb_id')
				try: result = cache.get(get_request, 96, url)['tv_results'][0]
				except: return None
		except:
			log_utils.error()
		return result


class Auth:
	def __init__(self):
		# self.auth_base_link = 'https://api.themoviedb.org/3/authentication'
		self.auth_base_link = '%s%s' % (base_link, 'authentication')


	def create_session_id(self):
		try:
			if control.setting('tmdb.username') == '' or control.setting('tmdb.password') == '':
				control.notification(message='TMDb Account info missing', icon='ERROR')
				return
			url = self.auth_base_link + '/token/new?api_key=%s' % API_key
			result = requests.get(url).json()
			# token = result.get('request_token').encode('utf-8')
			token = result.get('request_token')
			url2 = self.auth_base_link + '/token/validate_with_login?api_key=%s' % API_key
			post2 = {"username": "%s" % control.setting('tmdb.username'),
							"password": "%s" % control.setting('tmdb.password'),
							"request_token": "%s" % token}
			result2 = requests.post(url2, data=post2).json()
			url3 = self.auth_base_link + '/session/new?api_key=%s' % API_key
			post3 = {"request_token": "%s" % token}
			result3 = requests.post(url3, data=post3).json()
			if result3.get('success') is True:
				session_id = result3.get('session_id')
				msg = '%s' % ('username =' + username + '[CR]password =' + password + '[CR]token = ' + token + '[CR]confirm?')
				if control.yesnoDialog(msg, '', ''):
					control.setSetting('tmdb.session_id', session_id)
					control.notification(message='TMDb Successfully Authorized')
				else:
					control.notification(message='TMDb Authorization Cancelled')
		except:
			log_utils.error()


	def revoke_session_id(self):
		try:
			if control.setting('tmdb.session_id') == '':
				return
			url = self.auth_base_link + '/session?api_key=%s' % API_key
			post = {"session_id": "%s" % control.setting('tmdb.session_id')}
			result = requests.delete(url, data=post).json()
			if result.get('success') is True:
				control.setSetting('tmdb.session_id', '')
				control.notification(message='TMDb session_id successfully deleted')
			else:
				control.notification(message='TMDb session_id deletion FAILED', icon='ERROR')
		except:
			log_utils.error()