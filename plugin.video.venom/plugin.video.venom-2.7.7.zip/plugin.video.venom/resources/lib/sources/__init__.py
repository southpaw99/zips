# -*- coding: UTF-8 -*-


import pkgutil
import os.path,xbmc
import en
import en_DebridOnly
import en_Torrent
import de,es,gr,pl

from resources.lib.modules import log_utils

scraper_source = os.path.dirname(__file__)
__all__ = [x[1] for x in os.walk(os.path.dirname(__file__))][0]


##--en--##
hoster_source = en.sourcePath
hoster_providers = en.__all__


##--en_DebridOnly--##
debrid_source = en_DebridOnly.sourcePath
debrid_providers = en_DebridOnly.__all__


##--en_Torrent--##
torrent_source = en_Torrent.sourcePath
torrent_providers = en_Torrent.__all__


##--Paid Debrid(Debrid and Torrents)--##
paid_providers = {'en_DebridOnly': debrid_providers, 'en_Torrent': torrent_providers}
all_paid_providers = []
for key, value in paid_providers.iteritems():
    all_paid_providers += value


##--Foreign Providers--##
spanish_providers = es.__all__
german_providers = de.__all__
greek_providers = gr.__all__
polish_providers = pl.__all__


##--All Foreign Providers--##
foreign_providers = {'es': spanish_providers, 'de': german_providers, 'gr': greek_providers, 'pl': polish_providers}
all_foreign_providers = []
for key, value in foreign_providers.iteritems():
    all_foreign_providers += value


##--All Providers--##
total_providers = {'en': hoster_providers, 'en_Debrid': debrid_providers, 'en_Torrent': torrent_providers, 'de': german_providers, 'es': spanish_providers, 'gr': greek_providers, 'pl': polish_providers}
all_providers = []
for key, value in total_providers.iteritems():
    all_providers += value


try:
    import xbmcaddon
    __addon__ = xbmcaddon.Addon(id='plugin.video.venom')
except:
    __addon__ = None
    pass



def sources():
    try:
        sourceDict = []
        for i in __all__:
            for loader, module_name, is_pkg in pkgutil.walk_packages([os.path.join(os.path.dirname(__file__), i)]):
                if is_pkg:
                    continue
                try:
                    module = loader.find_module(module_name).load_module(module_name)
                    sourceDict.append((module_name, module.source()))
                except Exception as e:
                    log_utils.log('Could not load "%s": %s' % (module_name, e), log_utils.LOGDEBUG)
        return sourceDict
    except:
        return []


def getAllHosters():
    def _sources(sourceFolder, appendList):
        sourceFolderLocation = os.path.join(os.path.dirname(__file__), sourceFolder)
        sourceSubFolders = [x[1] for x in os.walk(sourceFolderLocation)][0]
        for i in sourceSubFolders:
            for loader, module_name, is_pkg in pkgutil.walk_packages([os.path.join(sourceFolderLocation, i)]):
                if is_pkg:
                    continue
                try: mn = str(module_name).split('_')[0]
                except: mn = str(module_name)
                appendList.append(mn)
    sourceSubFolders = [x[1] for x in os.walk(os.path.dirname(__file__))][0]
    appendList = []
    for item in sourceSubFolders:
        if item != 'modules':
            _sources(item, appendList)
    return list(set(appendList))