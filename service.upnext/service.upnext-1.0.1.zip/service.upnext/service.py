from resources.lib.monitor import Monitor

# start the monitor
Monitor().run()
