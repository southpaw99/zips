# -*- coding: utf-8 -*-


import json
import re
import requests
from sys import argv
import time
import xbmcaddon
import xbmcgui

from resources.lib.modules import control
from resources.lib.modules import log_utils
from resources.lib.modules.source_utils import supported_video_extensions

base_url = 'https://api.alldebrid.com/v4/'
user_agent = 'Venom for Kodi'


class AllDebrid:
	def __init__(self):
		self.token = control.addon('script.module.resolveurl').getSetting('AllDebridResolver_token')
		self.timeout = 25.0


	def _get(self, url, url_append=''):
		result = None
		try:
			if self.token == '': return None
			url = base_url + url + '?agent=%s&apikey=%s' % (user_agent, self.token) + url_append
			result = requests.get(url, timeout=self.timeout).json()
			if result.get('status') == 'success':
				if 'data' in result:
					result = result['data']
		except:
			log_utils.error()
			pass
		return result


	def _post(self, url, data={}):
		result = None
		try:
			if self.token == '': return None
			url = base_url + url + '?agent=%s&apikey=%s' % (user_agent, self.token)
			result = requests.post(url, data=data, timeout=self.timeout).json()
			if result.get('status') == 'success':
				if 'data' in result:
					result = result['data']
		except:
			log_utils.error()
			pass
		return result


	def auth_loop(self):
		control.sleep(5000)
		response = requests.get(self.check_url, timeout=self.timeout).json()
		response = response['data']
		if 'error' in response:
			self.token = 'failed'
			return control.notification(title='default', message=40021, icon='default')
		if response['activated']:
			try:
				control.progressDialog.close()
				self.token = str(response['apikey'])
				# __addon__.setSetting('ad.token', self.token)
				control.addon('script.module.resolveurl').setSetting('AllDebridResolver_token', self.token)
			except:
				self.token = 'failed'
				return control.notification(title='default', message=40021, icon='default')
		return


	def auth(self):
		self.token = ''
		url = base_url + 'pin/get?agent=%s' % user_agent
		response = requests.get(url, timeout=self.timeout).json()
		response = response['data']

		control.progressDialog.create(control.lang(40056))
		control.progressDialog.update(-1,
				control.lang(32513) % 'https://alldebrid.com/pin/',
				control.lang(32514) % response['pin'])
		self.check_url = response.get('check_url')
		control.sleep(2000)
		while not self.token:
			if control.progressDialog.iscanceled():
				control.progressDialog.close()
				break
			self.auth_loop()
		if self.token in (None, '', 'failed'):
			return
		control.sleep(2000)
		account_info = self._get('user')
		# __addon__.setSetting('ad.account_id', str(account_info['user']['username']))
		xbmcgui.Dialog().ok('Fen', ls(32576))


	def account_info(self):
		response = self._get('user')
		return response


	def check_cache(self, hashes):
		try:
			data = {'magnets[]': hashes}
			response = self._post('magnet/instant', data)
			return response
		except:
			log_utils.error()
		return None


	def check_single_magnet(self, hash_string):
		cache_info = self.check_cache(hash_string)['magnets'][0]
		return cache_info['instant']


	def user_cloud(self):
		url = 'magnet/status'
		string = "fen_ad_user_cloud"
		return cache_object(self._get, string, url, False, 2)


	def unrestrict_link(self, link):
		try:
			url = 'link/unlock'
			url_append = '&link=%s' % link
			response = self._get(url, url_append)
			return response['link']
		except:
			log_utils.error()
		return None


	def create_transfer(self, magnet):
		try:
			url = 'magnet/upload'
			url_append = '&magnet=%s' % magnet
			result = self._get(url, url_append)
			result = result['magnets'][0]
			log_utils.log('All Debrid: Sending MAGNET URL %s to the All Debrid cloud' % magnet, __name__, log_utils.LOGDEBUG)
			return result.get('id', "")
		except:
			log_utils.error()
		return None


	def list_transfer(self, transfer_id):
		try:
			url = 'magnet/status'
			url_append = '&id=%s' % transfer_id
			result = self._get(url, url_append)
			result = result['magnets']
			return result
		except:
			log_utils.error()
		return None


	def delete_transfer(self, transfer_id):
		try:
			url = 'magnet/delete'
			url_append = '&id=%s' % transfer_id
			result = self._get(url, url_append)
			if result.get('success', False):
				return True
		except:
			log_utils.error()
		return None


	def resolve_magnet_pack(self, magnet_url, season, episode, ep_title):
	# def resolve_magnet(self, magnet_url, info_hash, store_to_cloud, season, episode, ep_title):
		from resources.lib.modules.source_utils import seas_ep_filter, episode_extras_filter
		try:
			store_to_cloud = True
			file_url = None
			correct_files = []
			extensions = supported_video_extensions()
			extras_filtering_list = episode_extras_filter()
			transfer_id = self.create_transfer(magnet_url)
			transfer_info = self.list_transfer(transfer_id)
			if season:
				valid_results = [i for i in transfer_info.get('links') if any(i.get('filename').lower().endswith(x) for x in extensions) and not i.get('link', '') == '']
				log_utils.log('valid_results = %s' % str(valid_results), __name__, log_utils.LOGDEBUG)
				if len(valid_results) == 0:
					return
				for item in valid_results:
					# if seas_ep_filter(season, episode, item['filename']):
					if seas_ep_filter(season, episode, re.sub('[^A-Za-z0-9]+', '.', item['filename'].replace("\'", '')).lower()):
						correct_files.append(item)
					if len(correct_files) == 0:
						continue
					episode_title = re.sub('[^A-Za-z0-9-]+', '.', ep_title.replace('\'', '')).lower()
					log_utils.log('episode_title = %s' % str(episode_title), __name__, log_utils.LOGDEBUG)
					for i in correct_files:
						compare_link = re.sub('[^A-Za-z0-9-]+', '.', i['filename'].replace("\'", '')).lower()
						# compare_link = seas_ep_filter(season, episode, i['filename'], split=True)
						compare_link = seas_ep_filter(season, episode, compare_link, split=True)
						log_utils.log('compare_link = %s' % str(compare_link), __name__, log_utils.LOGDEBUG)
						compare_link = re.sub(episode_title, '', compare_link)
						log_utils.log('compare_link = %s' % str(compare_link), __name__, log_utils.LOGDEBUG)
						if not any(x in compare_link for x in extras_filtering_list):
							media_id = i['link']
							log_utils.log('media_id = %s' % str(media_id), __name__, log_utils.LOGDEBUG)
							break
			else:
				media_id = transfer_info['links'][0].get('link')
			if not store_to_cloud:
				self.delete_transfer(transfer_id)
			file_url = self.unrestrict_link(media_id)
			log_utils.log('file_url = %s' % str(file_url), __name__, log_utils.LOGDEBUG)
			return file_url
		except:
			log_utils.error()
			if transfer_id:
				self.delete_transfer(transfer_id)
			return None


	def display_magnet_pack(self, magnet_url, info_hash):
		try:
			extensions = supported_video_extensions()
			transfer_id = self.create_transfer(magnet_url)
			transfer_info = self.list_transfer(transfer_id)
			end_results = []
			for item in transfer_info.get('links'):
				if any(item.get('filename').lower().endswith(x) for x in extensions) and not item.get('link', '') == '':
					end_results.append({'link': item['link'], 'filename': item['filename'], 'size': item['size']})
			self.delete_transfer(transfer_id)
			return end_results
		except:
			log_utils.error()
			if transfer_id:
				self.delete_transfer(transfer_id)
			return None


	def add_uncached_torrent(self, magnet_url, pack=False):
		def _return_failed(message=control.lang(33586)):
			try:
				control.progressDialog.close()
			except Exception:
				pass
			self.delete_transfer(transfer_id)
			control.hide()
			control.sleep(500)
			control.okDialog(title=control.lang(40018), message=message)
			return False
		control.busy()
		transfer_id = self.create_transfer(magnet_url)
		if not transfer_id:
			return _return_failed()
		transfer_info = self.list_transfer(transfer_id)
		if not transfer_info:
			return _return_failed()
		if pack:
			# self.clear_cache()
			control.hide()
			control.okDialog(title='default', message=control.lang(40017) % control.lang(40059))
			return True
		interval = 5
		line1 = '%s...' % (control.lang(40017) % control.lang(40059))
		line2 = transfer_info['filename']
		line3 = transfer_info['status']
		control.progressDialog.create(control.lang(40018), line1, line2, line3)
		while not transfer_info['statusCode'] == 4:
			control.sleep(1000 * interval)
			transfer_info = self.list_transfer(transfer_id)
			file_size = transfer_info['size']
			line2 = transfer_info['filename']
			if transfer_info['statusCode'] == 1:
				download_speed = round(float(transfer_info['downloadSpeed']) / (1000**2), 2)
				progress = int(float(transfer_info['downloaded']) / file_size * 100) if file_size > 0 else 0
				line3 = control.lang(40016) % (download_speed, transfer_info['seeders'], progress, round(float(file_size) / (1000 ** 3), 2))
			elif transfer_info['statusCode'] == 3:
				upload_speed = round(float(transfer_info['uploadSpeed']) / (1000 ** 2), 2)
				progress = int(float(transfer_info['uploaded']) / file_size * 100) if file_size > 0 else 0
				line3 = control.lang(40015) % (upload_speed, progress, round(float(file_size) / (1000 ** 3), 2))
			else:
				line3 = transfer_info['status']
				progress = 0
			control.progressDialog.update(progress, line2=line2, line3=line3)
			if control.monitor.abortRequested():
				return sys.exit()
			try:
				if control.progressDialog.iscanceled():
					return _return_failed(control.lang(40014))
			except:
				pass
			if 5 <= transfer_info['statusCode'] <= 10:
				return _return_failed()
		control.sleep(1000 * interval)
		try:
			control.progressDialog.close()
		except:
			log_utils.error()
			pass
		control.hide()
		return True


	def valid_url(self, host):
		self.hosts = self.get_hosts()
		if any(host in item for item in self.hosts):
			return True
		return False


	def get_hosts(self):
		string = "fen_ad_valid_hosts"
		url = 'hosts'
		hosts_dict = {'AllDebrid': []}
		hosts = []
		try:
			result = cache_object(self._get, string, url, False, 24)
			result = result['hosts']
			for k, v in result.items():
				try: hosts.extend(v['domains'])
				except: pass
			hosts = list(set(hosts))
			hosts_dict['AllDebrid'] = [i.split('.', 1)[0] for i in hosts]
		except:
			log_utils.error()
			pass
		return hosts_dict


	def revoke_auth(self):
		__addon__.setSetting('ad.account_id', '')
		__addon__.setSetting('ad.token', '')
		xbmcgui.Dialog().ok(ls(32063), '%s %s' % (ls(32059), ls(32576)))


	def clear_cache(self):
		try:
			import xbmc, xbmcvfs
			import os
			AD_DATABASE = os.path.join(xbmc.translatePath(__addon__.getAddonInfo('profile')), 'fen_cache2.db')
			if not xbmcvfs.exists(AD_DATABASE): return True
			try: from sqlite3 import dbapi2 as database
			except ImportError: from pysqlite2 import dbapi2 as database
			window = xbmcgui.Window(10000)
			dbcon = database.connect(AD_DATABASE)
			dbcur = dbcon.cursor()
			dbcur.execute("""DELETE FROM fencache WHERE id=?""", ('fen_ad_user_cloud',))
			window.clearProperty('fen_ad_user_cloud')
			dbcon.commit()
			dbcon.close()
			return True
		except:
			return False
