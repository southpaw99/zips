addon_id = 'script.module.metahandler'

#set movie/tvshow constants
type_movie = 'movie'
type_tvshow = 'tvshow'
type_season = 'season'        
type_episode = 'episode'